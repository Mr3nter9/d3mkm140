from telethon.sync import TelegramClient
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetHistoryRequest
import re
from telethon import functions
import requests
from time import sleep
def dex1():
    v = input("  How many Accounts to add?  ")
    c = input("  How many Accounts you added?  ")
    G = (int(c)+1)
    b=int(v)+int(c)
    for ffguf in range(int(v)):
        cc = ("dex" + str(G))
        api_id = '2192036'
        api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
        client = TelegramClient(cc, api_id, api_hash)
        client.start()
        client(JoinChannelRequest('@d3boot_7'))
        client(JoinChannelRequest('@DzDDDD'))
        client(JoinChannelRequest('@botbillion'))
        client(JoinChannelRequest('@zzzzzz1'))
        client(JoinChannelRequest('@Fvvvv'))
        client.session.save()
        client.disconnect()
        if G == b:
            print("  Completed")
            break
        G += 1
dex1()