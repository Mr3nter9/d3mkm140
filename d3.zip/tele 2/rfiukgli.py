

from telethon.sync import TelegramClient
api_id = '22160733'
api_hash = 'c95e81b40eba3404ac130f4a9f235e4c'


client=TelegramClient('dex35', api_id, api_hash)
client.start()
chats='@dexsuper'
x=client.get_messages(chats, limit=1)
client.
